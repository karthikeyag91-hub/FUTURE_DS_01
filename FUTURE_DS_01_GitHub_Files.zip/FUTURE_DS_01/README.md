# FUTURE_DS_01 - Business Sales Performance Analytics

## Task
Analyze business sales data to identify revenue trends, top-selling products, high-value categories, and regional performance.

## Tools Used
- Python
- Pandas
- Matplotlib
- CSV Dataset

## Files Included
- sales_analysis.py
- sales_data.csv
- requirements.txt

## How to Run
```bash
pip install -r requirements.txt
python sales_analysis.py
```

## Key Insights
- Total revenue and total units sold are calculated.
- Monthly revenue trend is analyzed.
- Top-selling products are identified.
- Category-wise and region-wise performance are compared.
