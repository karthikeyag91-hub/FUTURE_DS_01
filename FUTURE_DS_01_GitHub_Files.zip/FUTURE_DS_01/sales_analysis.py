import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("sales_data.csv")
df["Date"] = pd.to_datetime(df["Date"])

total_revenue = df["Revenue"].sum()
total_units = df["Units_Sold"].sum()
average_order_value = df["Revenue"].mean()

print("BUSINESS SALES PERFORMANCE ANALYTICS")
print("-----------------------------------")
print("Total Revenue:", total_revenue)
print("Total Units Sold:", total_units)
print("Average Order Value:", round(average_order_value, 2))

monthly_revenue = df.groupby(df["Date"].dt.to_period("M"))["Revenue"].sum()
top_products = df.groupby("Product")["Revenue"].sum().sort_values(ascending=False)
category_sales = df.groupby("Category")["Revenue"].sum().sort_values(ascending=False)
region_sales = df.groupby("Region")["Revenue"].sum().sort_values(ascending=False)

print("\nMonthly Revenue:")
print(monthly_revenue)
print("\nTop Products:")
print(top_products)
print("\nCategory Sales:")
print(category_sales)
print("\nRegional Sales:")
print(region_sales)

monthly_revenue.plot(kind="line", marker="o", title="Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("monthly_revenue_trend.png")
plt.close()

top_products.plot(kind="bar", title="Top-Selling Products")
plt.xlabel("Product")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("top_selling_products.png")
plt.close()

category_sales.plot(kind="bar", title="Revenue by Category")
plt.xlabel("Category")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("category_performance.png")
plt.close()

region_sales.plot(kind="bar", title="Regional Performance")
plt.xlabel("Region")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig("regional_performance.png")
plt.close()

print("\nCharts created successfully.")
